<?php

/**
 * Add contact to your GetResponse campaign when order is made.
 *
 * @author Pawel Pabian
 * http://implix.com
 * http://dev.getresponse.com
 */

    define('MODULE_ORDER_TOTAL_GETRESPONSE_TITLE', 'GetResponse');
    define('MODULE_ORDER_TOTAL_GETRESPONSE_DESCRIPTION', 'Add customer data to GetResponse campaign whenever order is placed');
?>