<?php
/**
*
* @package phpBB3
* @version $Id$
* @copyright (c) 2005 phpBB Group
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

/**
* Messenger
* @package phpBB3
*/
class getresponse
{
    function add_subscriber($name, $email)
    {
        global $phpbb_root_path, $config;

        if ( !empty($config['gr_api_key'])
                and
             !empty($config['gr_campaign'])
                and
             !empty($config['gr_signup_enable'])
                and
             1 == $config['gr_signup_enable']
                and
             file_exists($phpbb_root_path . 'files/jsonRPCClient.php')
        )
        {
            require_once $phpbb_root_path . 'files/jsonRPCClient.php';
            $client = new jsonRPCClient('http://api2.getresponse.com');
            $result = NULL;

            try
            {
                $result = $client->add_contact(
                    $config['gr_api_key'],
                    array (
                        'campaign'  => $config['gr_campaign'],
                        'name'      => $name,
                        'email'     => $email,
                        'cycle_day' => '0'
                    )
                );
            }
            catch (Exception $e){}
        }
    }
}

?>