<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{getresponse}prestashop>getresponsesubtab_48db5695a0cb7fe32946081e5cdcd710'] = 'Ustawienia API Key';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_94a6261f786e09eb88f6399502bec007'] = 'Klucz API';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_a485a6ab8b6df59e69eaa715b384387c'] = 'Klucz można znaleźć na stronie: https://app.getresponse.pl/my_api_key.html';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_7dc1ae2bef1d1bb7e729a1926291f19b'] = 'Wyeksportuj użytkowników';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_4778cc549312829644c3a8b26e76c2d2'] = 'Kampania';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_0095a9fa74d1713e43e370a7d7846224'] = 'Eksportuj';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_a455505d4d10ec0d981c945c83f78f3d'] = 'Wybierz kampanię do której wyeksportować kontakty';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_56dfc25884230b83b0f2169f156237b1'] = 'Zapisz do listy na stronie zakupu';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_2cf781e42b786113c8bde0d37f58e9d0'] = 'Zapisz do kampanii';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_075ae3d2fc31640504f814f60e5ef713'] = 'Wyłącz';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_a10311459433adf322f2590a4987c423'] = 'Włącz';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_a4d3b161ce1309df1c4e25df28694b7b'] = 'Zapisz';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_ccd7b247c2804670c9208d5583ffbe9d'] = 'Wybierz kampanię do której kontakt zostanie dodany.';
$_MODULE['<{getresponse}prestashop>getresponsesubtab_69649d52b17b01c2994bb289a88c7a13'] = 'Włącz/wyłącz zapis na stronie zakupu.';
$_MODULE['<{getresponse}prestashop>getresponse_f0180d584c18095d3476faa8b844434a'] = 'GetResponse Integration';
$_MODULE['<{getresponse}prestashop>getresponse_71e0e74855165f4293e05c8ef8071c02'] = 'Zintegruj sklep z GetResponse';
